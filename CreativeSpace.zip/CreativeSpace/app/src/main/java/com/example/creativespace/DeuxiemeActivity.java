package com.example.creativespace;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DeuxiemeActivity extends AppCompatActivity {
    private Button btnPost, btnExit;
    private TextView welcomeText;
    private EditText poemEditText;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deuxieme);

        // Initialize views
        btnPost = findViewById(R.id.button2);
        btnExit = findViewById(R.id.btn_exit);
        welcomeText = findViewById(R.id.welcome);
        poemEditText = findViewById(R.id.editTextText);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("POEM_DATA", MODE_PRIVATE);

        // Set welcome message with username
        String userName = getIntent().getStringExtra("USER_NAME");
        if (userName != null && !userName.isEmpty()) {
            welcomeText.setText("Welcome " + userName);
        }

        // Load saved poem when activity starts
        loadSavedPoem();

        btnPost.setOnClickListener(v -> {
            String poem = poemEditText.getText().toString();
            savePoem(poem);
            Toast.makeText(this, "Poem saved!", Toast.LENGTH_SHORT).show();
        });

        btnExit.setOnClickListener(v -> finish());
    }

    private void loadSavedPoem() {
        String savedPoem = sharedPreferences.getString("SAVED_POEM", "");
        if(!savedPoem.isEmpty()) {
            poemEditText.setText(savedPoem);
        }
    }

    private void savePoem(String poem) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("SAVED_POEM", poem);
        editor.apply();
    }
}