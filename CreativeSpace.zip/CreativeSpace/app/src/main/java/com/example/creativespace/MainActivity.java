package com.example.creativespace;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText nom;
    private Button suivant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nom = findViewById(R.id.edt_nom);
        suivant = findViewById(R.id.btn_suivant);

        suivant.setOnClickListener(v -> {
            String userName = nom.getText().toString();
            Intent intent = new Intent(MainActivity.this, DeuxiemeActivity.class);
            intent.putExtra("USER_NAME", userName);
            startActivity(intent);
        });
    }
}